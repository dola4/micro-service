from main import (create_user, login_user, get_profil, delete_profil, update_profil,
                   create_request, get_request, delete_request, get_all_requests,
                   delete_all_requests, delete_all_recieved_requests, create_notification) 



# call all the functions of .main.py
#create_user()
#login_user()
#get_profil()
#update_profil()
#delete_profil()
##############################################
# je suis rendu a tester et rendre fonctionnelles les fonction suivante :
#  
#create_request()
#get_request()
#delete_request()
#get_all_requests()
#delete_all_requests()
#delete_all_recieved_requests()
#create_notification()
